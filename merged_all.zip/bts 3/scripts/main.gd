extends Node2D

const fish_encyc_scene: PackedScene = preload("res://scenes/fish_encyc.tscn")
#@onready var open_encyc: TextureButton = $fish_log
var encyc_instance: CanvasLayer = null



func _physics_process(delta: float) -> void:
	if Input.is_action_pressed("Hook"):
			print("hooking")
			$Player.process_mode = Node.PROCESS_MODE_DISABLED
			$Player/AnimatedSprite2D.stop()
			$Player/AnimatedSprite2D.frame = 1


func _on_fish_log_pressed() -> void:
	if(encyc_instance != null):
		return
	encyc_instance = fish_encyc_scene.instantiate()
	add_child(encyc_instance)
	encyc_instance.closed.connect(_on_encyc_closed)
	
func _on_encyc_closed() -> void:
	if encyc_instance != null:
		encyc_instance.queue_free()
		encyc_instance = null
