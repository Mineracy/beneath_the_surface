extends Node

const loading_screen = preload("res://scenes/loading.tscn")
var next_scene_path: String = ""

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

#this gets the desired or target scene then loads it as you view the loading screen made for this
func load_scene(path : String):
	next_scene_path = path
	get_tree().change_scene_to_packed(loading_screen)
	print(path)
	
#fullscreen toggle function
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("fullscreen"):
		print("input read")
		if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		else:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta: float) -> void:
#	pass
