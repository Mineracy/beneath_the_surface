extends PanelContainer

@onready var fish_icon: TextureRect = $"VBoxContainer/Header/fish icon"
@onready var fish_name: Label = $"VBoxContainer/Header/fish name"
@onready var value_label: Label = $VBoxContainer/Header/value
@onready var catch_id_label: Label = $"VBoxContainer/Header/catch id"
@onready var expand_button: Button = $VBoxContainer/Header/expand

@onready var expanded_box: VBoxContainer = $VBoxContainer/expanded
@onready var sci_name_label: Label = $"VBoxContainer/expanded/sci name"
@onready var avg_len_label: Label = $"VBoxContainer/expanded/avg len"
@onready var avg_lbs_label: Label = $"VBoxContainer/expanded/avg lbs"
@onready var conservation_label: Label = $VBoxContainer/expanded/conservation
@onready var fun_fact_label: Label = $"VBoxContainer/expanded/fun fact"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	expanded_box.visible = false
	expand_button.toggle_mode = true
#	expand_button.toggled.connect(_on_expand_toggled)

func enterData(icon: String, fishName: String, value: int, id: int, sciName: String, avgLen: String, avgLBS: String, conser: String, funFact: String) -> void:
	fish_icon.texture = load(icon)
	fish_name.text = fishName
	value_label.text = str("$%d" % value)
	catch_id_label.text = str("Catch #"+str(id))
	sci_name_label.text = str("Scientific Name: "+sciName)
	avg_len_label.text = str("Average Length: "+avgLen)
	avg_lbs_label.text = str("Average Weight: "+avgLBS)
	conservation_label.text = str("Conservation Status: "+conser)
	fun_fact_label.text = str("Fun Fact: "+funFact)
	
	
	

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta: float) -> void:
#	pass


func _on_expand_toggled(toggled_on: bool) -> void:
	expanded_box.visible = toggled_on
