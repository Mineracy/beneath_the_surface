extends Control

var progress: Array[float]

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	ResourceLoader.load_threaded_request(GlobalSceneManager.next_scene_path)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var status = ResourceLoader.load_threaded_get_status(GlobalSceneManager.next_scene_path, progress)
	
	if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
		$Label.text= str("Loading... ",progress[0]*100)
		pass
	elif status == ResourceLoader.THREAD_LOAD_LOADED:
		$Label.text= "Loaded!"
		#$AnimationPlayer.play("fade_out")
		var loaded_scene = ResourceLoader.load_threaded_get(GlobalSceneManager.next_scene_path)
		get_tree().change_scene_to_packed(loaded_scene)
	elif status == ResourceLoader.THREAD_LOAD_FAILED:
		push_error("Failed to load scene: " + GlobalSceneManager.next_scene_path)
