extends CanvasLayer

signal closed

var mynode = preload("res://scenes/fish_entry.tscn")
var counter = 1
@onready var list_container: VBoxContainer = $ScrollContainer/VBoxContainer

func addEntry(fishType: String, value: int) -> void:
	var instance = mynode.instantiate()
	var iconPath: String = "res://icon.svg"
	var sciName: String = ""
	var avgLen: String = ""
	var avgWgt: String = ""
	var conserve: String = ""
	var funFact: String = ""
	
	if(fishType == "Clownfish"):
		iconPath = "res://assets/textures/Fish/cropped/clownfish_cropped.png"
		sciName = "Amphiprion ocellaris"
		avgLen = "3.15in"
		avgWgt = "0.7 to 2.5oz"
		conserve = "Least concern"
		funFact = "Clownfish live in the tentacles of sea anemone. The anemone provides shelter and protection to the clownfish, and in return the clownfish removes parasites from the anemone. The clownfish has a special mucus that keeps it safe from the anemone’s sting."
	if(fishType == "Great Barracuda"):
		iconPath = "res://assets/textures/Fish/cropped/great barracuda_cropped.png"
		sciName = "Sphyraena barracuda"
		avgLen = "24 to 39in"
		avgWgt = "5.5 to 19.8lb"
		conserve = "Least concern"
		funFact = "Barracudas are capable of short bursts of speed up to 36 mph, though they sacrifice maneuverability. They use this speed for an ambush style of hunting, where they surprise and overrun their prey. "
	if(fishType=="Redfin Anthias"):
		iconPath = "res://assets/textures/Fish/cropped/redfin anthias_cropped.png"
		sciName = "Nemanthias dispar"
		avgLen = "3.5 to 4in"
		avgWgt = "0.37 to 0.7lb"
		conserve = "Least concern"
		funFact = "Redfin anthias are carnivores, eating animal plankton. They swim against the current so that their prey floats right to them. "
	if(fishType=="Convict Surgeonfish"):
		iconPath = "res://assets/textures/Fish/cropped/convict surgeonfish_cropped.png"
		sciName = "Acanthurus triostegus"
		avgLen = "10 to 11in"
		avgWgt = "1.76lb"
		conserve = "Least concern"
		funFact = "The convict surgeonfish’s “convict” nickname comes from its six bold black stripes on a pale yellow body, which resemble the striped uniforms of historic prison inmates."
	if(fishType=="Yellowtail Coris"):
		iconPath = "res://assets/textures/Fish/cropped/yellowrail coris_cropped.png"
		sciName = "Coris gaimard"
		avgLen = "7.9in"
		avgWgt = "0.4 to 2.2lb"
		conserve = "Least concern"
		funFact = "Yellowtail coris change their color as they mature. They start out as bright red with large, white spots and change to have an orange body with blue spots and yellow tails when they mature."

	if(fishType=="Long-Jawed Squirrelfish"):
		iconPath = "res://assets/textures/Fish/cropped/long-jawed squirrelfish_cropped.png"
		sciName = "Sargocentron spiniferum"
		avgLen = "14 to 20in"
		avgWgt = "2.2 to 3.5lb"
		conserve = "Least concern"
		funFact = "Long-jawed squirrelfish are nocturnal and are the largest species of squirrelfish."
	if(fishType=="Turkey Fish"):
		iconPath = "res://assets/textures/Fish/cropped/turkey fish_cropped.png"
		sciName = "Pterois volitans"
		avgLen = "12 to 15in"
		avgWgt = "2.5lb"
		conserve = "Least concern"
		funFact = "Lionfish, or turkey fish,  have about 18 venomous spines that they use both as defense against predators and to herd prey."
	if(fishType=="Moorish Fish"):
		iconPath = "res://assets/textures/Fish/cropped/moorish fish_cropped.png"
		sciName = "Zanclus cornutus"
		avgLen = "7 to 8.3in"
		avgWgt = "3.5 to 8.8oz"
		conserve = "Least concern"
		funFact = "You may recognize this fish from Finding Nemo. Gill is a Moorish idol, and just like Gill’s constant need to escape, these fish are notoriously difficult to keep in aquariums."
	if(fishType=="Palette Surgeonfish"):
		iconPath = "res://assets/textures/Fish/cropped/convict surgeonfish_cropped.png"
		sciName = "Paracanthurus hepatus"
		avgLen = "10 to 12in"
		avgWgt = "1.3lb"
		conserve = "Least concern"
		funFact = "Surgeonfish get their name from the sharp spines they have, which are extended when they feel threatened."
	if(fishType=="Bullethead Parrotfish"):
		iconPath = "res://assets/textures/Fish/cropped/bullethead parrotfish_cropped.png"
		sciName = "Chlorurus sordidus"
		avgLen = "5.9in"
		avgWgt = "0.65 to 1.65lb"
		conserve = "Least concern"
		funFact = "Bullethead parrotfish get their name from the beak-like structure of their mouth that’s actually fused teeth. They use this beak to scrape algae off rocks and bite into coral."
	
	
	list_container.add_child(instance)
	#instance.reparent(list_container)
	instance.enterData(iconPath,fishType,value,counter,sciName,avgLen,avgWgt,conserve,funFact)
	counter+= 1
	pass


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#addEntry("Clownfish", 1) Test cases for adding fishes to the scrolly list
	addEntry("Great Barracuda", 2)
	addEntry("Redfin Anthias", 3)
	addEntry("Convict Surgeonfish", 4)
	#addEntry("Yellowtail Coris", 5)
	#addEntry("Long-Jawed Squirrelfish", 6)
	#addEntry("Turkey Fish", 7)
	#addEntry("Moorish Fish", 8)
	#addEntry("Palette Surgeonfish", 9)
	#addEntry("Bullethead Parrotfish", 10)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta: float) -> void:
#	pass


func _on_close_pressed() -> void:
	closed.emit()
