shader_type canvas_item;

// Where the black starts to fade out
uniform float threshold : hint_range(0.0, 1.0) = 0.05;
// How wide the anti-aliased edge transition should be
uniform float softness : hint_range(0.001, 0.5) = 0.15;

void fragment() {
    vec4 tex_color = texture(TEXTURE, UV);
    
    // Find the brightest RGB channel of the current pixel
    float brightness = max(tex_color.r, max(tex_color.g, tex_color.b));
    
    // Smoothly fade alpha from 0.0 to 1.0 across the edge
    float alpha = smoothstep(threshold, threshold + softness, brightness);
    
    // Remove the black tint from semi-transparent edge pixels
    if (alpha > 0.001) {
        tex_color.rgb /= alpha;
    }
    
    // Clamp RGB values so they don't blow out above 1.0
    tex_color.rgb = clamp(tex_color.rgb, 0.0, 1.0);
    
    COLOR = vec4(tex_color.rgb, tex_color.a * alpha);
}
