extends Node2D

const fish_encyc_scene: PackedScene = preload("res://scenes/fish_encyc.tscn")
@onready var open_encyc: TextureButton = $open_encyc

var encyc_instance: CanvasLayer = null

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if open_encyc:
		pass
#		open_encyc.pressed.connect(_on_open_encyc_pressed)
		
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_open_encyc_pressed() -> void:
	if(encyc_instance != null):
		return
	encyc_instance = fish_encyc_scene.instantiate()
	add_child(encyc_instance)
	encyc_instance.closed.connect(_on_encyc_closed)

func _on_encyc_closed() -> void:
	if encyc_instance != null:
		encyc_instance.queue_free()
		encyc_instance = null
