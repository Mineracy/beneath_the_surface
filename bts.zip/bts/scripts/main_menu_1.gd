extends Control
@onready var options_menu: Control = $Options
@onready var menu_options_container: VBoxContainer = $MainMenu/HBoxContainer/VBoxContainer/MenuOptions

@onready var master_bus_idx: int = AudioServer.get_bus_index("Master")
@onready var music_bus_idx: int = AudioServer.get_bus_index("Music")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	options_menu.visible = false
	$Options/VBoxContainer/MasterAudio.value = 100.0
	$Options/VBoxContainer/MusicAudio.value = 100.0
	
	_on_master_audio_value_changed(100.0)
	_on_music_audio_value_changed(100.0)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_new_game_pressed() -> void:
	print("New")
	pass # Replace with function body.


func _on_continue_pressed() -> void:
	print("Cont.")
	pass # Replace with function body.


func _on_options_pressed() -> void:
	print("Options")
	options_menu.visible = true
	menu_options_container.process_mode = PROCESS_MODE_DISABLED


func _on_close_pressed() -> void:
	options_menu.visible = false
	menu_options_container.process_mode = PROCESS_MODE_INHERIT


func _on_master_audio_value_changed(value: float) -> void:
	var pct = value / 100.0
	var db = linear_to_db(pct)
	AudioServer.set_bus_volume_db(master_bus_idx, db)
	AudioServer.set_bus_mute(master_bus_idx, value == 0.0)


func _on_music_audio_value_changed(value: float) -> void:
	var pct = value / 100.0
	var db = linear_to_db(pct)
	AudioServer.set_bus_volume_db(music_bus_idx, db)
	AudioServer.set_bus_mute(music_bus_idx, value == 0.0)
