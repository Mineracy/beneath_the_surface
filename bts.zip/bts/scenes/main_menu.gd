extends MarginContainer


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_new_game_pressed() -> void:
	print("New Game")


func _on_continue_pressed() -> void:
	print("Continue")


func _on_options_pressed() -> void:
	print("Options")
