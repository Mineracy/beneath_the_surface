extends Sprite2D

#Variable setup. To change speed of fish, change the speed float.
@export var speed: float = 100.0
var move_direction: Vector2 = Vector2.RIGHT
var time_passed: float = 0.0
var screen_size: Vector2
var fish_timer: float = randf_range(0,4)


# Called when the node enters the scene tree for the first time.
#Basic setup, sets scale, position of fish and sets viewport size.
func _ready() -> void:
	scale = Vector2(.02,.02)
	position = Vector2(0,randi_range(200, 600))
	screen_size = get_viewport_rect().size


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#Setup, starts the timer, updates position, makes sure sprite is facing right direction.
	time_passed += delta
	position += move_direction*speed*delta
	flip_v = move_direction.x < 0
	
	#Fish bounces off left and right screen edge
	if position.x <= 0:
		position.x = 0
		move_direction.x = abs(move_direction.x)
	elif position.x >= screen_size.x:
		position.x = screen_size.x
		move_direction.x = -abs(move_direction.x)
			
	#FIsh bounces off bottomm and top screen edge
	if position.y <= 0.0:
		position.y = 0.0
		move_direction.y = abs(move_direction.y)
	elif position.y >= screen_size.y:
		position.y = screen_size.y
		move_direction.y = -abs(move_direction.y)

	#Changes the angle the fish swims at when the timer is up.
	if time_passed >= fish_timer:
		#A 1 in 10 chance to set direction of swimming to a totally random angle.
		if randf() <= 0.1:
			move_direction = Vector2.RIGHT.rotated(randf_range(0, 15))
			reset_time()
		#A 1 in 2 chance to change direction by 5-15 degrees up.
		elif randf() <= 0.5:
			var up_angle = deg_to_rad(randf_range(-15.0, -5.0))
			move_direction = move_direction.rotated(up_angle)
			reset_time()
		#Changes direction by 5-15 degrees down.
		else:
			var down_angle = deg_to_rad(randf_range(5.0, 15.0))
			move_direction = move_direction.rotated(down_angle)
			reset_time()
			
	#Makes the sprite face direction of travel.
	rotation = move_direction.angle()


#Resets the timer.	
func reset_time() -> void:
	time_passed = 0.0
	fish_timer = randf_range(2,6)
