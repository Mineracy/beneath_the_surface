extends CharacterBody2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D


const SPEED = 300.0
func _physics_process(delta: float) -> void:
	
	if velocity.x > 1 or velocity.x < -1:
		animated_sprite_2d.animation = "Moving"
	else:
		animated_sprite_2d.animation = "Idle"
	
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	var direction := Input.get_axis("moveLeft_ui", "moveRight_ui")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	
