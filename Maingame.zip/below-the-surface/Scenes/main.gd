extends Node2D

func _physics_process(delta: float) -> void:
	if Input.is_action_pressed("Hook"):
			print("hooking")
			$Player.process_mode = Node.PROCESS_MODE_DISABLED
			$Player/AnimatedSprite2D.stop()
			$Player/AnimatedSprite2D.frame = 1
